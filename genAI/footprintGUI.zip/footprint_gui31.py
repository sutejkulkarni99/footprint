import sys
import cv2
import numpy as np
from scipy.spatial import KDTree
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QLabel, QPushButton, QVBoxLayout,
    QHBoxLayout, QWidget, QFileDialog, QInputDialog, QMessageBox,
    QTextEdit, QGridLayout
)
from PySide6.QtGui import QImage, QPixmap, QTextCursor
from PySide6.QtCore import Qt
import pyqtgraph as pg
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, Polygon
import cadquery as cq
from cadquery import exporters

def create_ipc7351_footprint(filename, footprint_name, num_pins, pitch,
                            pin_diameter, border_width, border_height,
                            component_type="Through-Hole", pin_rows=None):
    if not isinstance(filename, str):
        raise ValueError("Filename must be a string.")
    if not isinstance(footprint_name, str):
        raise ValueError("Footprint name must be a string.")
    if num_pins <= 0 or not isinstance(num_pins, int):
        raise ValueError("Number of pins must be a positive integer.")
    if pitch <= 0:
        raise ValueError("Pitch must be a positive number.")
    if pin_diameter <= 0:
        raise ValueError("Pin diameter must be a positive number.")
    if border_width <= 0 or border_height <= 0:
        raise ValueError("Border dimensions must be positive numbers.")
    if component_type not in ["SMD", "Through-Hole"]:
        raise ValueError("Invalid component type")
    if not pin_rows or len(pin_rows) == 0:
        raise ValueError("Pin rows must be provided")

    pad_type = "smd" if component_type == "SMD" else "thru_hole"
    content = f"""(module {footprint_name} (layer F.Cu) (tedit 12345678)
  (descr "IPC-7351 compliant footprint")
  (tags "connector")
  (attr {component_type.lower()})
  (fp_text reference J1 (at 0 {-border_height/2 - 2}) (layer F.SilkS)
    (effects (font (size 1 1) (thickness 0.15))))
  (fp_text value {footprint_name} (at 0 {border_height/2 + 2}) (layer F.Fab)
    (effects (font (size 1 1) (thickness 0.15))))"""

    # Silkscreen outline
    content += f"""
  (fp_line (start {-border_width/2} {-border_height/2}) (end {border_width/2} {-border_height/2}) (layer F.SilkS) (width 0.15))
  (fp_line (start {border_width/2} {-border_height/2}) (end {border_width/2} {border_height/2}) (layer F.SilkS) (width 0.15))
  (fp_line (start {border_width/2} {border_height/2}) (end {-border_width/2} {border_height/2}) (layer F.SilkS) (width 0.15))
  (fp_line (start {-border_width/2} {border_height/2}) (end {-border_width/2} {-border_height/2}) (layer F.SilkS) (width 0.15))"""

    # Pads
    pin_number = 1
    for row_idx, row in enumerate(pin_rows):
        for i, (x, y) in enumerate(row):
            pad_x = i * pitch - (len(row) - 1) * pitch / 2
            pad_y = row_idx * pitch
            content += f"""
  (pad {pin_number} {pad_type} rect (at {pad_x} {pad_y}) (size 1.5 1.5) (layers *.Cu *.Mask F.SilkS))"""
            pin_number += 1

    content += "\n)"
    with open(filename, "w") as f:
        f.write(content)
    print(f"Footprint saved as {filename}")

class PinCalibrationApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("PCB Footprint Generator")
        self.setGeometry(100, 100, 1280, 720)
        
        # State variables
        self.image_path = None
        self.image_rgb = None
        self.original_image = None
        self.edges = None
        self.edge_points = None
        self.edge_kdtree = None
        self.pin_rows = []
        self.current_row = []
        self.square_points = []
        self.calibration_points = []
        self.lasso_points = []
        self.homography_matrix = None
        self.pixel_to_mm_ratio = None
        self.rotation_correction = True
        
        # UI Setup
        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)
        self.layout = QHBoxLayout(self.central_widget)
        
        # Control Panel
        self.control_panel = QWidget()
        self.control_layout = QGridLayout(self.control_panel)
        self.layout.addWidget(self.control_panel, stretch=1)
        
        # Image Display
        self.image_panel = QWidget()
        self.image_layout = QVBoxLayout(self.image_panel)
        self.layout.addWidget(self.image_panel, stretch=3)
        
        # Widgets
        self.create_widgets()
        self.setup_connections()
        
        # Visualization items
        self.image_view = pg.ImageView()
        self.image_layout.addWidget(self.image_view)
        self.pin_scatter = pg.ScatterPlotItem(pen='r', symbol='o', size=10)
        self.calibration_scatter = pg.ScatterPlotItem(pen='b', symbol='x', size=10)
        self.square_scatter = pg.ScatterPlotItem(pen='g', symbol='s', size=10)
        self.image_view.getView().addItem(self.pin_scatter)
        self.image_view.getView().addItem(self.calibration_scatter)
        self.image_view.getView().addItem(self.square_scatter)
        
    def create_widgets(self):
        buttons = [
            ("Load Image", self.load_image),
            ("Select Square", self.start_selecting_square),
            ("Calibrate Ruler", self.start_calibration),
            ("Select Pins", self.start_selecting_pins),
            ("Add Row", self.add_new_row),
            ("Calculate Pitch", self.calculate_pitch),
            ("Generate Drawing", self.generate_2d_drawing),
            ("Generate STEP", self.generate_step_file_dialog),
            ("Generate Footprint", self.generate_footprint),
            ("Reset", self.reset)
        ]
        
        for i, (text, handler) in enumerate(buttons):
            btn = QPushButton(text)
            btn.clicked.connect(handler)
            btn.setFixedSize(150, 40)
            self.control_layout.addWidget(btn, i, 0)
            
        self.result_text = QTextEdit()
        self.result_text.setReadOnly(True)
        self.control_layout.addWidget(self.result_text, len(buttons)+1, 0)

    def setup_connections(self):
        self.image_view.scene.sigMouseClicked.connect(self.on_mouse_click)
        self.image_view.scene.sigMouseMoved.connect(self.on_mouse_move)

    # --------------------- Core Functionality ---------------------
    def load_image(self):
        path, _ = QFileDialog.getOpenFileName(self, "Open Image", "", "Images (*.jpg *.png)")
        if not path: return
        
        self.original_image = cv2.imread(path)
        if self.original_image is None:
            QMessageBox.critical(self, "Error", "Failed to load image")
            return
        
        # Edge detection
        gray = cv2.cvtColor(self.original_image, cv2.COLOR_BGR2GRAY)
        self.edges = cv2.Canny(gray, 100, 200)
        self.edge_points = np.column_stack(np.where(self.edges > 0))
        self.edge_kdtree = KDTree(self.edge_points) if len(self.edge_points) > 0 else None
        
        # Prepare display image
        self.image_rgb = cv2.cvtColor(self.original_image, cv2.COLOR_BGR2RGB)
        edges_rgb = cv2.cvtColor(self.edges, cv2.COLOR_GRAY2RGB)
        edges_rgb[self.edges > 0] = [0, 255, 0]
        self.display_image(cv2.addWeighted(self.image_rgb, 0.7, edges_rgb, 0.3, 0))
        self.update_result("Image loaded. Select square corners first.")

    def display_image(self, image):
        if self.rotation_correction:
            self.image_view.setImage(np.rot90(image, k=-1))
        else:
            self.image_view.setImage(image)
        self.image_view.getView().invertY(False)

    def adjust_coordinates(self, x, y):
        """Convert display coordinates to original image space with perspective correction"""
        if self.rotation_correction and self.image_rgb is not None:
            h, w = self.image_rgb.shape[:2]
            x_orig = h - y - 1
            y_orig = x
        else:
            x_orig, y_orig = x, y

        if self.homography_matrix is not None:
            src_pt = np.array([[[x_orig, y_orig]]], dtype="float32")
            dst_pt = cv2.perspectiveTransform(src_pt, self.homography_matrix)
            return dst_pt[0][0]
        return (x_orig, y_orig)

    def on_mouse_click(self, event):
        pos = self.image_view.getView().mapSceneToView(event.pos())
        x, y = int(pos.x()), int(pos.y())
        x_corr, y_corr = self.adjust_coordinates(x, y)

        if self.selecting_square:
            self.handle_square_click(x_corr, y_corr)
        elif self.selecting_calibration:
            self.handle_calibration_click(x_corr, y_corr)
        elif self.selecting_pins:
            self.handle_pin_click(x_corr, y_corr)

    def handle_square_click(self, x, y):
        self.square_points.append((x, y))
        self.square_scatter.addPoints([x], [y])
        
        if len(self.square_points) == 4:
            self.calculate_homography()

    def calculate_homography(self):
        src_points = np.array(self.square_points, dtype="float32")
        size_mm, ok = QInputDialog.getDouble(self, "Square Size", 
                                           "Enter square side length (mm):",
                                           50.0, 1.0, 1000.0, 2)
        if not ok: return
        
        dst_points = np.array([
            [0, 0],
            [size_mm, 0],
            [size_mm, size_mm],
            [0, size_mm]
        ], dtype="float32")
        
        self.homography_matrix, _ = cv2.findHomography(src_points, dst_points)
        self.update_result(f"Perspective correction applied\nHomography matrix:\n{self.homography_matrix}")

    def handle_calibration_click(self, x, y):
        self.calibration_points.append((x, y))
        if len(self.calibration_points) == 2:
            self.calculate_calibration()

    def calculate_calibration(self):
        pt1, pt2 = np.array(self.calibration_points, dtype="float32")
        distance_px = np.linalg.norm(pt2 - pt1)
        distance_mm, ok = QInputDialog.getDouble(self, "Calibration",
                                               "Enter known distance (mm):",
                                               100.0, 1.0, 1000.0, 2)
        if not ok: return
        
        self.pixel_to_mm_ratio = distance_mm / distance_px
        self.update_result(f"Calibration complete\n1px = {self.pixel_to_mm_ratio:.4f}mm")

    def handle_pin_click(self, x, y):
        self.current_row.append((x, y))
        color = self.row_colors[len(self.pin_rows) % len(self.row_colors)]
        self.pin_scatter.addPoints([x], [y], pen=color, brush=color)
        self.update_result(f"Pin {len(self.current_row)} placed at ({x:.2f}, {y:.2f}) mm")

    def calculate_border_width(self):
        if not self.pin_rows: return 10.0
        all_x = [pin[0] for row in self.pin_rows for pin in row]
        return max((max(all_x) - min(all_x)) + 5.0, 10.0)

    def calculate_border_height(self):
        if not self.pin_rows: return 10.0
        all_y = [pin[1] for row in self.pin_rows for pin in row]
        return max((max(all_y) - min(all_y)) + 5.0, 10.0)

    def generate_footprint(self):
        try:
            border_w = self.calculate_border_width()
            border_h = self.calculate_border_height()
            
            file_path, _ = QFileDialog.getSaveFileName(self, "Save Footprint",
                                                     "", "KiCad Files (*.kicad_mod)")
            if not file_path: return
            
            create_ipc7351_footprint(
                file_path, "Generated_Footprint",
                sum(len(row) for row in self.pin_rows),
                2.54, 1.0, border_w, border_h,
                "Through-Hole", self.pin_rows
            )
            self.update_result(f"Footprint saved to {file_path}")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Generation failed: {str(e)}")

    # --------------------- Helper Methods ---------------------
    def update_result(self, text):
        self.result_text.append(text)
        self.result_text.moveCursor(QTextCursor.End)

    def reset(self):
        self.image_view.clear()
        self.pin_scatter.clear()
        self.calibration_scatter.clear()
        self.square_scatter.clear()
        self.pin_rows = []
        self.current_row = []
        self.square_points = []
        self.calibration_points = []
        self.homography_matrix = None
        self.pixel_to_mm_ratio = None
        self.update_result("System reset")

    # ... (Other methods like generate_2d_drawing, generate_step_file, etc.)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = PinCalibrationApp()
    window.show()
    sys.exit(app.exec())